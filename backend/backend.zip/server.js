const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { initDatabase } = require('./database');
const config = require('./config');

// Load environment variables with error handling
try {
  require('dotenv').config();
  console.log('✅ Environment variables loaded successfully');
} catch (error) {
  console.error('❌ Failed to load environment variables:', error.message);
  process.exit(1);
}

// Import routes with error handling
let authRoutes, publicationsRoutes, servicesRoutes, experiencesRoutes, physiciansRoutes, newsRoutes, galleryRoutes, testimonialsRoutes;

try {
  authRoutes = require('./routes/auth');
  publicationsRoutes = require('./routes/publications');
  servicesRoutes = require('./routes/services');
  experiencesRoutes = require('./routes/experiences');
  physiciansRoutes = require('./routes/physicians');
  newsRoutes = require('./routes/news');
  galleryRoutes = require('./routes/gallery');
  testimonialsRoutes = require('./routes/testimonials');
  console.log('✅ All routes loaded successfully');
} catch (error) {
  console.error('❌ Failed to load routes:', error.message);
  process.exit(1);
}

const app = express();

// Enhanced CORS configuration with error handling
try {
  app.use(cors({
    origin: function (origin, callback) {
      // Allow requests with no origin (mobile apps, curl, etc.)
      if (!origin) return callback(null, true);
      
      const allowedOrigins = [
        'http://localhost:3000',
        'http://localhost:5173',
        'https://drhabtamuorthopedics.com',
        'https://www.drhabtamuorthopedics.com'
      ];
      
      if (allowedOrigins.indexOf(origin) !== -1) {
        callback(null, true);
      } else {
        console.warn(`⚠️  CORS blocked origin: ${origin}`);
        callback(new Error('Not allowed by CORS'));
      }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
  }));
  console.log('✅ CORS middleware configured');
} catch (error) {
  console.error('❌ CORS configuration failed:', error.message);
  process.exit(1);
}

// Body parsing middleware with error handling
try {
  app.use(express.json({ 
    limit: '10mb',
    verify: (req, res, buf) => {
      try {
        JSON.parse(buf);
      } catch (e) {
        console.error('❌ Invalid JSON in request body');
        throw new Error('Invalid JSON');
      }
    }
  }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));
  console.log('✅ Body parsing middleware configured');
} catch (error) {
  console.error('❌ Body parsing middleware failed:', error.message);
  process.exit(1);
}

// Serve uploaded files statically with error handling
try {
  const uploadsDir = path.join(__dirname, 'uploads');
  
  // Ensure uploads directory exists
  if (!fs.existsSync(uploadsDir)) {
    console.log('📁 Creating uploads directory...');
    fs.mkdirSync(uploadsDir, { recursive: true });
  }
  
  app.use('/uploads', express.static(uploadsDir));
  console.log('✅ Static file serving configured');
} catch (error) {
  console.error('❌ Static file serving failed:', error.message);
  process.exit(1);
}

// Serve static files from dist folder in production with error handling
if (config.server.env === 'production') {
  try {
    const distPath = path.join(__dirname, '..', 'dist');
    
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      console.log('✅ Production static files configured');
    } else {
      console.warn('⚠️  Dist folder not found. Frontend may not be built.');
    }
  } catch (error) {
    console.error('❌ Production static files failed:', error.message);
    // Don't exit, just log the error as this is not critical
  }
}

// Routes with error handling
try {
  app.use('/api/auth', authRoutes);
  app.use('/api/publications', publicationsRoutes);
  app.use('/api/services', servicesRoutes);
  app.use('/api/experiences', experiencesRoutes);
  app.use('/api/physicians', physiciansRoutes);
  app.use('/api/news', newsRoutes);
  app.use('/api/gallery', galleryRoutes);
  app.use('/api/testimonials', testimonialsRoutes);
  console.log('✅ API routes registered');
} catch (error) {
  console.error('❌ Failed to register API routes:', error.message);
  process.exit(1);
}

// Health check endpoint with detailed information
app.get('/api/health', (req, res) => {
  try {
    const healthInfo = {
      status: 'OK',
      message: 'DHMC Backend API is running',
      timestamp: new Date().toISOString(),
      environment: config.server.env,
      port: config.server.port,
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      version: process.version,
      platform: process.platform
    };
    
    res.json(healthInfo);
  } catch (error) {
    console.error('❌ Health check failed:', error.message);
    res.status(500).json({
      status: 'ERROR',
      message: 'Health check failed',
      error: error.message
    });
  }
});

// Enhanced error handling middleware
app.use((error, req, res, next) => {
  console.error('❌ Global error handler:', {
    error: error.message,
    stack: error.stack,
    url: req.url,
    method: req.method,
    ip: req.ip,
    userAgent: req.get('User-Agent'),
    timestamp: new Date().toISOString()
  });
  
  // Don't expose internal errors in production
  const isDevelopment = config.server.env === 'development';
  
  res.status(error.status || 500).json({
    error: 'Internal server error',
    message: isDevelopment ? error.message : 'Something went wrong',
    ...(isDevelopment && { stack: error.stack })
  });
});

// 404 handler with error handling
app.use('*', (req, res) => {
  try {
    // In production, serve index.html for non-API routes (SPA fallback)
    if (config.server.env === 'production' && !req.originalUrl.startsWith('/api')) {
      const indexPath = path.join(__dirname, '..', 'dist', 'index.html');
      
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).json({
          error: 'Not found',
          message: 'Frontend not built or index.html missing'
        });
      }
    } else {
      res.status(404).json({
        error: 'Not found',
        message: 'The requested resource was not found',
        path: req.originalUrl
      });
    }
  } catch (error) {
    console.error('❌ 404 handler failed:', error.message);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Error handling 404 request'
    });
  }
});

// Start server with comprehensive error handling
const startServer = async () => {
  try {
    console.log('🚀 Starting server...');
    
    // Initialize database - commented out to avoid executing queries on startup
    // await initDatabase();
    
    // Start listening with error handling
    const PORT = config.server.port;
    const server = app.listen(PORT, (error) => {
      if (error) {
        console.error('❌ Failed to start server:', error.message);
        process.exit(1);
      }
      
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`📊 Health check: http://localhost:${PORT}/api/health`);
      console.log(`📁 Upload directory: ${path.join(__dirname, 'uploads')}`);
      console.log(`🌍 Environment: ${config.server.env}`);
    });
    
    // Handle server errors
    server.on('error', (error) => {
      if (error.code === 'EADDRINUSE') {
        console.error(`❌ Port ${PORT} is already in use`);
        console.error('Please either:');
        console.error('1. Stop the process using this port');
        console.error('2. Use a different port by setting PORT environment variable');
      } else {
        console.error('❌ Server error:', error.message);
      }
      process.exit(1);
    });
    
    // Graceful shutdown handling
    const gracefulShutdown = (signal) => {
      console.log(`\n📡 Received ${signal}. Starting graceful shutdown...`);
      
      server.close((error) => {
        if (error) {
          console.error('❌ Error during server shutdown:', error.message);
          process.exit(1);
        }
        
        console.log('✅ Server closed successfully');
        process.exit(0);
      });
      
      // Force close after 10 seconds
      setTimeout(() => {
        console.error('❌ Forced shutdown after timeout');
        process.exit(1);
      }, 10000);
    };
    
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
  } catch (error) {
    console.error('❌ Failed to start server:', error.message);
    console.error('Stack trace:', error.stack);
    process.exit(1);
  }
};

// Enhanced uncaught exception handling
process.on('uncaughtException', (error) => {
  console.error('❌ Uncaught Exception:', {
    error: error.message,
    stack: error.stack,
    timestamp: new Date().toISOString()
  });
  
  // Attempt graceful shutdown
  setTimeout(() => {
    console.error('❌ Forcing exit due to uncaught exception');
    process.exit(1);
  }, 1000);
});

// Enhanced unhandled rejection handling
process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Unhandled Rejection at:', {
    promise: promise,
    reason: reason,
    timestamp: new Date().toISOString()
  });
  
  // Attempt graceful shutdown
  setTimeout(() => {
    console.error('❌ Forcing exit due to unhandled rejection');
    process.exit(1);
  }, 1000);
});

// Start the server
startServer();

module.exports = app;
