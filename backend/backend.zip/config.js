// Configuration validation and error handling
const validateConfig = () => {
  const errors = [];
  const warnings = [];

  // Validate required environment variables
  const requiredVars = ['DB_NAME', 'DB_USER', 'DB_PASSWORD'];
  requiredVars.forEach(varName => {
    if (!process.env[varName] && !process.env.DATABASE_URL) {
      errors.push(`Missing required environment variable: ${varName}`);
    }
  });

  // Validate JWT secret
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET === 'your-super-secret-jwt-key-change-in-production') {
    warnings.push('JWT_SECRET is using default value. Change this in production!');
  }

  // Validate port
  const port = parseInt(process.env.PORT || '5000');
  if (isNaN(port) || port < 1 || port > 65535) {
    errors.push('Invalid PORT value. Must be a number between 1 and 65535');
  }

  // Validate file size limit
  const maxFileSize = parseInt(process.env.MAX_FILE_SIZE || '10485760');
  if (isNaN(maxFileSize) || maxFileSize < 1024) {
    errors.push('Invalid MAX_FILE_SIZE value. Must be at least 1024 bytes');
  }

  // Log warnings
  if (warnings.length > 0) {
    console.warn('⚠️  Configuration warnings:');
    warnings.forEach(warning => console.warn(`   - ${warning}`));
  }

  // Log errors and exit if critical
  if (errors.length > 0) {
    console.error('❌ Configuration errors:');
    errors.forEach(error => console.error(`   - ${error}`));
    console.error('Please fix these errors before starting the server.');
    process.exit(1);
  }

  console.log('✅ Configuration validation passed');
};

// Run validation
try {
  validateConfig();
} catch (error) {
  console.error('❌ Configuration validation failed:', error.message);
  process.exit(1);
}

module.exports = {
  // Database Configuration
  database: process.env.DATABASE_URL ? {
    // Use connection string for deployment (Heroku, Railway, etc.)
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    // Connection pool settings for production
    max: parseInt(process.env.DB_MAX_CONNECTIONS) || 20,
    idleTimeoutMillis: parseInt(process.env.DB_IDLE_TIMEOUT) || 30000,
    connectionTimeoutMillis: parseInt(process.env.DB_CONNECTION_TIMEOUT) || 2000,
  } : {
    // Use individual parameters for local development
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT) || 5432,
    database: process.env.DB_NAME || 'habtamu_db_web',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || '1234',
    // Connection pool settings for development
    max: parseInt(process.env.DB_MAX_CONNECTIONS) || 10,
    idleTimeoutMillis: parseInt(process.env.DB_IDLE_TIMEOUT) || 30000,
    connectionTimeoutMillis: parseInt(process.env.DB_CONNECTION_TIMEOUT) || 2000,
  },
  
  // Server Configuration
  server: {
    port: parseInt(process.env.PORT) || 5000,
    env: process.env.NODE_ENV || 'production'
  },
  
  // File Upload Configuration
  upload: {
    dir: process.env.UPLOAD_DIR || 'uploads',
    maxFileSize: parseInt(process.env.MAX_FILE_SIZE) || 10485760 // 10MB
  },
  
  // API Configuration
  api: {
    baseUrl: process.env.API_BASE_URL || 'https://drhabtamuorthopedics.com/api',
    uploadsBaseUrl: process.env.UPLOADS_BASE_URL || 'https://drhabtamuorthopedics.com/uploads'
  },
  
  // Authentication Configuration
  auth: {
    jwtSecret: process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-in-production',
    tokenExpiry: process.env.JWT_EXPIRY || '24h'
  }
};
