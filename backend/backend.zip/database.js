const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const config = require('./config');

// Database connection pool with comprehensive error handling
let pool;

try {
  pool = new Pool(config.database);
  console.log('✅ Database connection pool created successfully');
} catch (error) {
  console.error('❌ Failed to create database connection pool:', error.message);
  console.error('Database configuration:', {
    host: config.database.host || 'connection string',
    port: config.database.port,
    database: config.database.database,
    user: config.database.user,
    ssl: config.database.ssl
  });
  process.exit(1);
}

// Enhanced connection event handlers
pool.on('connect', (client) => {
  console.log('✅ Connected to PostgreSQL database');
  console.log('Connection details:', {
    processId: client.processID,
    database: client.database,
    user: client.user,
    host: client.host,
    port: client.port
  });
});

pool.on('error', (err, client) => {
  console.error('❌ Database connection error:', {
    error: err.message,
    code: err.code,
    detail: err.detail,
    hint: err.hint,
    position: err.position,
    internalPosition: err.internalPosition,
    internalQuery: err.internalQuery,
    where: err.where,
    schema: err.schema,
    table: err.table,
    column: err.column,
    dataType: err.dataType,
    constraint: err.constraint,
    file: err.file,
    line: err.line,
    routine: err.routine,
    timestamp: new Date().toISOString()
  });
  
  // Don't exit immediately, let the pool handle reconnection
  console.warn('⚠️  Database connection lost, attempting to reconnect...');
});

// Database query helper function with comprehensive error handling
const query = async (text, params = []) => {
  const start = Date.now();
  let client;
  
  try {
    // Validate input parameters
    if (typeof text !== 'string' || text.trim() === '') {
      throw new Error('Query text must be a non-empty string');
    }
    
    if (!Array.isArray(params)) {
      throw new Error('Query parameters must be an array');
    }
    
    // Get client from pool
    client = await pool.connect();
    
    // Execute query with timeout
    const queryPromise = client.query(text, params);
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Query timeout after 30 seconds')), 30000);
    });
    
    const res = await Promise.race([queryPromise, timeoutPromise]);
    const duration = Date.now() - start;
    
    // Log successful query
    console.log('✅ Executed query:', {
      text: text.substring(0, 100) + (text.length > 100 ? '...' : ''),
      duration: `${duration}ms`,
      rows: res.rowCount,
      timestamp: new Date().toISOString()
    });
    
    return res;
    
  } catch (error) {
    const duration = Date.now() - start;
    
    // Enhanced error logging
    console.error('❌ Database query error:', {
      error: error.message,
      code: error.code,
      detail: error.detail,
      hint: error.hint,
      position: error.position,
      query: text.substring(0, 200) + (text.length > 200 ? '...' : ''),
      params: params,
      duration: `${duration}ms`,
      timestamp: new Date().toISOString()
    });
    
    // Handle specific PostgreSQL errors
    if (error.code) {
      switch (error.code) {
        case 'ECONNREFUSED':
          console.error('❌ Database connection refused. Check if PostgreSQL is running.');
          break;
        case 'ENOTFOUND':
          console.error('❌ Database host not found. Check host configuration.');
          break;
        case 'ETIMEDOUT':
          console.error('❌ Database connection timeout. Check network connectivity.');
          break;
        case '28P01':
          console.error('❌ Database authentication failed. Check username/password.');
          break;
        case '3D000':
          console.error('❌ Database does not exist. Check database name.');
          break;
        case '42P01':
          console.error('❌ Table does not exist. Check if schema is initialized.');
          break;
        case '23505':
          console.error('❌ Unique constraint violation. Duplicate entry detected.');
          break;
        case '23503':
          console.error('❌ Foreign key constraint violation. Referenced record does not exist.');
          break;
        case '23502':
          console.error('❌ Not null constraint violation. Required field is missing.');
          break;
        default:
          console.error(`❌ PostgreSQL error code: ${error.code}`);
      }
    }
    
    throw error;
    
  } finally {
    // Always release the client back to the pool
    if (client) {
      try {
        client.release();
      } catch (releaseError) {
        console.error('❌ Error releasing database client:', releaseError.message);
      }
    }
  }
};

// Test database connection
const testConnection = async () => {
  try {
    console.log('🔍 Testing database connection...');
    const result = await query('SELECT NOW() as current_time, version() as pg_version');
    console.log('✅ Database connection test successful:', {
      currentTime: result.rows[0].current_time,
      version: result.rows[0].pg_version
    });
    return true;
  } catch (error) {
    console.error('❌ Database connection test failed:', error.message);
    return false;
  }
};

// Initialize database tables with comprehensive error handling
const initDatabase = async () => {
  try {
    console.log('🚀 Initializing database...');
    
    // Test connection first
    const isConnected = await testConnection();
    if (!isConnected) {
      throw new Error('Database connection test failed');
    }
    
    // Read schema file with error handling
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    
    if (!fs.existsSync(schemaPath)) {
      throw new Error(`Schema file not found at: ${schemaPath}`);
    }
    
    let schema;
    try {
      schema = fs.readFileSync(schemaPath, 'utf8');
    } catch (readError) {
      throw new Error(`Failed to read schema file: ${readError.message}`);
    }
    
    if (!schema || schema.trim() === '') {
      throw new Error('Schema file is empty');
    }
    
    console.log('📄 Schema file loaded successfully');
    
    // Execute schema with error handling
    try {
      await query(schema);
      console.log('✅ Database tables initialized successfully');
    } catch (schemaError) {
      // Check if tables already exist
      if (schemaError.code === '42P07') {
        console.log('ℹ️  Database tables already exist, skipping initialization');
      } else {
        throw schemaError;
      }
    }
    
    // Create initial admin user with error handling
    try {
      console.log('👤 Creating initial admin user...');
      const { createInitialAdmin } = require('./scripts/createInitialAdmin');
      await createInitialAdmin(query);
      console.log('✅ Initial admin user setup completed');
    } catch (adminError) {
      console.error('❌ Failed to create initial admin user:', adminError.message);
      // Don't throw here, as this is not critical for database initialization
      console.warn('⚠️  You can create admin users manually later');
    }
    
    console.log('🎉 Database initialization completed successfully');
    
  } catch (error) {
    console.error('❌ Database initialization failed:', {
      error: error.message,
      code: error.code,
      detail: error.detail,
      hint: error.hint,
      timestamp: new Date().toISOString()
    });
    
    // Provide helpful suggestions based on error type
    if (error.code === 'ECONNREFUSED') {
      console.error('💡 Suggestions:');
      console.error('   1. Check if PostgreSQL is running');
      console.error('   2. Verify database connection settings');
      console.error('   3. Check firewall settings');
    } else if (error.code === '28P01') {
      console.error('💡 Suggestions:');
      console.error('   1. Check database username and password');
      console.error('   2. Verify user has proper permissions');
    } else if (error.code === '3D000') {
      console.error('💡 Suggestions:');
      console.error('   1. Create the database first');
      console.error('   2. Check database name spelling');
    }
    
    throw error;
  }
};

// Graceful shutdown function
const closePool = async () => {
  try {
    console.log('🔄 Closing database connection pool...');
    await pool.end();
    console.log('✅ Database connection pool closed successfully');
  } catch (error) {
    console.error('❌ Error closing database connection pool:', error.message);
  }
};

// Handle process termination
process.on('SIGTERM', closePool);
process.on('SIGINT', closePool);

module.exports = {
  query,
  pool,
  initDatabase,
  testConnection,
  closePool
};
